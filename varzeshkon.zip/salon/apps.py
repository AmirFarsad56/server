from django.apps import AppConfig


class SalonConfig(AppConfig):
    name = 'salon'
