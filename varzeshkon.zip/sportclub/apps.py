from django.apps import AppConfig


class SportclubConfig(AppConfig):
    name = 'sportclub'
