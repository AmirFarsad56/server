from django.contrib import admin
from masteruser.models import MasterUserModel

admin.site.register(MasterUserModel)
