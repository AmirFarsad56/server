from django.apps import AppConfig


class MasteruserConfig(AppConfig):
    name = 'masteruser'
