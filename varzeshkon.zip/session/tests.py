i = [0,]
print(len(i))
