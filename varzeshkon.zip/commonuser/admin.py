from django.contrib import admin
from commonuser.models import CommonUserModel

admin.site.register(CommonUserModel)
