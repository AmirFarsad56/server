from django.apps import AppConfig


class CommonuserConfig(AppConfig):
    name = 'commonuser'
